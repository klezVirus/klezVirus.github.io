<?php namespace App\Http\Middleware;

use Closure;
use Request;

class ApiAuth {

    /**
     * Handle an incoming request and check that its authed.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        if (!\App\Key::where(['uuid' => Request::header('X-UUID'), 'token' => Request::header('X-Token')])->first())
            return response()
                ->json(['error' => 'Invalid authentication headers.'], 401);

        return $next($request);
    }

}
