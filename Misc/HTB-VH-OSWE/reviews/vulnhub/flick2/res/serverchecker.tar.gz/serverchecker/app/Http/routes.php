<?php

use Symfony\Component\Process\Process;

// curl -v -H "Content-Type: application/json" -X GET "http://192.168.217.248/register/status/00000-231234fds-sdffdg2-321"
// curl -v -H "Content-Type: application/json" -X POST -d '{"uuid":"00000-231234fds-sdffdg2-32"}' "http://192.168.217.248/register/new"
// curl -v -H "Content-Type: application/json" -H "X-UUID: 00000-231234fds-sdffdg2-32" -H "X-Token: pkx1GlBJobUNigoKVLTQG2D730kINEvM" -X GET "http://192.168.217.248/do/cmd/$(echo -n "ps" | base64)"

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

$app->get('/', function() use ($app) {
    return response()
        ->json(['Server Checker']);
});

$app->get('/ping', function() use ($app) {
    return response()
        ->json(['response' => 'pong']);
});

$app->group(['prefix' => 'register'], function () use ($app) {

    // Return the registration status of a uuid
    $app->get('/status/{uuid}', function($uuid) use ($app) {

        $status = App\Key::where('uuid', $uuid)->first();

        if($status)
            return response()
                ->json(['registered' => 'yes']);

        return response()
            ->json(['registered' => 'no']);
    });

    // Register a new UUID
    $app->post('/new', function() use ($app) {

        // Do we have the UUID in the request?
        if (!Request::has('uuid'))
            return response()
                ->json([
                    'error' => 'A UUID is required.'
                ], 400);
				
		$fd = Request::input('uuid');
        // Register the UUID by creating a token
        // and storing it in the database.
        // 
        // If the UUID is already registered, then
        // we can just re-create the access token.
        $key = App\Key::firstOrNew(['uuid' => Request::input('uuid')]);
        
		// Generate new token
		$key->token = twist_random(32, $fd);
        $key->save();

        return response()
            ->json([
                'registered' => 'ok',
                'message' => 'The requested UUID is now registered.',
                'token' => $key->token
            ]);
    });
});

$app->group(['prefix' => 'do', 'middleware' => 'api_auth'], function () use ($app) {

    // Return the registration status of a uuid
    $app->get('/cmd/{command}', function($command) use ($app) {

        if (base64_decode($command, true) === False)
            return response()
                ->json([
                    'status' => 'error',
                    'output' => 'Bad command format.'
                ]);

        // Get the command...
        $command = base64_decode($command);

        // ... and filter it
        $bad_commands = [
            '/bash/i',
            '/cat/i',
            '/cc/i',
            '/chpasswd/i',
            '/chmod/i',
            '/chown/i',
            '/dig/i',
            '/diff/i',
            '/echo/i',
            '/exec/i',
            '/gcc/i',
            '/gcc++/i',
            '/gzip/i',
            '/history/i',
            '/host/i',
            '/ip/i',
            '/java/i',
            '/last/i',
            '/ls/i',
            '/lsof/i',
            '/mkfifo/i',
            '/mknod/i',
            '/mount/i',
            '/nc/i',
            '/nice/i',
            '/netcat/i',
            '/perl/i',
            '/php/i',
            '/passwd/i',
            '/python/i',
            '/ruby/i',
            '/rm/i',
            '/rpm/i',
            '/sh/i',
            '/ssh/i',
            '/strings/i',
            '/tail/i',
            '/tar/i',
            '/telnet/i',
            '/top/i',
            '/touch/i',
            '/unzip/i',
            '/useradd/i',
            '/vi/i',
            '/vim/i',
            '/which/i',
            '/who/i',
            '/whoami/i',
            '/which/i',
            '/xhost/i',
            '/xterm/i',
            '/yum/i',
            '/base64/i',
            '@^\/@',
            '@^\.\/@'
        ];

        // Filter out the commands that could be dodge. Ofc, this blacklist
        // approach is *SUPER* fail, but hey, this is the point I guess :)
        // 
        
		$bad = FALSE;
		
		foreach ( $bad_commands as $bc ){
			if(preg_match($bc,$command)){
				$bad = TRUE;
			}
		}
		
		if($bad) {

            return response()
                ->json([
                    'status' => 'error',
                    'output' => 'Command \'' . $command . '\' contains a banned command.'
                ]);
        }

        $process = new Process($command);
        $process->run();

        if (!$process->isSuccessful()) {
            return response()
                ->json([
                    'status' => 'error',
                    'output' => $process->getErrorOutput()
                ]);
        }

        return response()
            ->json([
                'status' => 'ok',
                'command' => $command,
                'output' => $process->getOutput()
            ]);
    });

});

