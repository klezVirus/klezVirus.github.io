<?php

function twist_random($length = 32, $uuid = NULL)
{
	$pool = $uuid ? join(array_unique(str_split(str_replace("-","",$uuid)))) : join(array_unique(str_split(str_random($length))));	
    return substr(str_shuffle(str_repeat($pool, $length)), 0, $length-1);
}

?>